```{include} ../../README.md
:relative-images:
```

```{toctree}
:caption: 'Contents:'
:maxdepth: 2
api/modules
```

# Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
